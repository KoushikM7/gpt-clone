const apiKey = "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"

export default apiKey